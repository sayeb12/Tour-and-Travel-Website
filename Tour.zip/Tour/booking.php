<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "travel";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$packagePrices = [
    'normal' => 100,
    'premium' => 200
];

$roomPrices = [
    'ac' => 50,
    'non_ac' => 30
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $packageType = $_POST['package_type'];
    $venue = $_POST['venue'];
    $daysToStay = $_POST['days_to_stay'];
    $roomType = $_POST['room_type'];
    
    $packagePrice = $packagePrices[$packageType];
    $roomPrice = $roomPrices[$roomType];
    $totalPrice = ($packagePrice + $roomPrice) * $daysToStay;

    // Handle image upload
    $imagePath = '';
    if (!empty($_FILES['image']['name'])) {
        $imagePath = 'image/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }

    $stmt = $conn->prepare("INSERT INTO bookings (package_type, venue, days_to_stay, room_type, price, image_path) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisss", $packageType, $venue, $daysToStay, $roomType, $totalPrice, $imagePath);

    if ($stmt->execute()) {
        header("Location: booking.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            padding: 20px;
        }

        .booking-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            text-align: center;
            margin-bottom: 20px;
        }

        .booking-container h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .booking-container label {
            display: block;
            text-align: left;
            color: #333;
            margin: 10px 0 5px;
        }

        .booking-container select,
        .booking-container input[type="number"],
        .booking-container input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: border-color 0.3s;
        }

        .booking-container select:focus,
        .booking-container input[type="number"]:focus,
        .booking-container input[type="file"]:focus {
            border-color: #007BFF;
        }

        .booking-container button {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .booking-container button:hover {
            background-color: #0056b3;
        }

        .bookings-list {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 800px;
            text-align: left;
            margin-top: 20px;
        }

        .bookings-list h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .booking-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .booking-item:last-child {
            border-bottom: none;
        }

        .booking-item p {
            margin: 5px 0;
        }

        .booking-item img {
            max-width: 100px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="booking-container">
            <h1>Book a Package</h1>
            <form action="booking.php" method="post" enctype="multipart/form-data">
                <label for="package_type">Package Type:</label>
                <select name="package_type" id="package_type" required>
                    <option value="normal">Normal</option>
                    <option value="premium">Premium</option>
                </select>
                
                <label for="venue">Venue:</label>
                <select name="venue" id="venue" required>
                    <option value="Venue 1">Venue 1</option>
                    <option value="Venue 2">Venue 2</option>
                    <option value="Venue 3">Venue 3</option>
                </select>
                
                <label for="days_to_stay">Days to Stay:</label>
                <input type="number" name="days_to_stay" id="days_to_stay" required min="1">
                
                <label for="room_type">Room Type:</label>
                <select name="room_type" id="room_type" required>
                    <option value="ac">AC</option>
                    <option value="non_ac">Non AC</option>
                </select>
                
                <label for="image">Upload Image:</label>
                <input type="file" name="image" id="image" required>
                
                <button type="submit">Confirm</button>
            </form>
        </div>

        <div class="bookings-list">
            <h2>Booking Details</h2>
            <?php
            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM bookings";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='booking-item'>";
                    echo "<p><strong>Package Type:</strong> " . htmlspecialchars($row['package_type']) . "</p>";
                    echo "<p><strong>Venue:</strong> " . htmlspecialchars($row['venue']) . "</p>";
                    echo "<p><strong>Days to Stay:</strong> " . htmlspecialchars($row['days_to_stay']) . "</p>";
                    echo "<p><strong>Room Type:</strong> " . htmlspecialchars($row['room_type']) . "</p>";
                    echo "<p><strong>Price:</strong> $" . htmlspecialchars($row['price']) . "</p>";
                    echo "<p><strong>Image:</strong><br><img src='" . htmlspecialchars($row['image_path']) . "' alt='Image'></p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No bookings found.</p>";
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
