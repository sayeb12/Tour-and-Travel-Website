
    // JavaScript to add sliding animation
    document.addEventListener('DOMContentLoaded', () => {
        const elements = document.querySelectorAll('.element');
        elements.forEach((element, index) => {
            element.style.animationDelay = `${index * 0.1}s`;
            element.classList.add('slide-in');
        });
    });



document.addEventListener("DOMContentLoaded", function() {
    const customerReviews = document.getElementById('.customer-reviews');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    observer.observe(customerReviews);
});
