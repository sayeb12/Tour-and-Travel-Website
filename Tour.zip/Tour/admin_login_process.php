<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_email = $mysqli->real_escape_string($_POST['admin_email']);
    $admin_password = $mysqli->real_escape_string($_POST['admin_password']);

    // Retrieve admin from database
    $sql = "SELECT * FROM admins WHERE admin_email = '$admin_email'";
    $result = $mysqli->query($sql);

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        // Verify password
        if (password_verify($admin_password, $admin['admin_password'])) {
            // Start session and store admin id
            session_start();
            $_SESSION['admin_id'] = $admin['id'];
            
            // Redirect to admin panel
            header("Location: admin_panel.php");
            exit;
        } else {
            echo "Invalid password";
        }
    } else {
        echo "Admin not found";
    }
    
    // Close the connection
    $mysqli->close();
}
?>
