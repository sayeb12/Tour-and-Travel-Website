<?php
include 'connect.php';

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Fetch all users
$sql = "SELECT * FROM users";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    $users = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $users = [];
}

// Handle delete user request
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $user_id = $mysqli->real_escape_string($_GET['delete']);

    $sql = "DELETE FROM users WHERE id = '$user_id'";
    if ($mysqli->query($sql) === TRUE) {
        header("Location: admin_panel.php");
        exit;
    } else {
        echo "Error deleting record: " . $mysqli->error;
    }
}

// Ensure $mysqli is connected to the database
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_user'])) {
    $user_id = $mysqli->real_escape_string($_POST['user_id']);
    $name = $mysqli->real_escape_string($_POST['name']);
    $email = $mysqli->real_escape_string($_POST['email']);
    $phone = $mysqli->real_escape_string($_POST['phone']);
    $address = $mysqli->real_escape_string($_POST['address']);

    // Check if all fields are not empty (optional, but good practice)
    if (empty($user_id) || empty($name) || empty($email) || empty($phone) || empty($address)) {
        echo "All fields are required.";
        exit;
    }

    $sql = "UPDATE users SET name='$name', email='$email', phone='$phone', address='$address' WHERE id='$user_id'";

    if ($mysqli->query($sql) === TRUE) {
        header("Location: admin_panel.php");
        exit;
    } else {
        echo "Error updating record: " . $mysqli->error;
    }
}

// Handle search user request
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['search'])) {
    $search_query = $mysqli->real_escape_string($_GET['search']);

    $sql = "SELECT * FROM users WHERE name LIKE '%$search_query%'";
    $result = $mysqli->query($sql);

    if ($result->num_rows > 0) {
        $users = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $users = [];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .btn {
            padding: 8px 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .edit-form {
            display: inline-block;
        }
        .edit-form input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }
        .edit-form input[type="submit"]:hover {
            background-color: #218838;
        }
        .edit-form input[type="button"] {
            background-color: #dc3545;
            color: white;
            border: none;
            cursor: pointer;
            margin-left: 10px;
        }
        .edit-form input[type="button"]:hover {
            background-color: #c82333;
        }
        .search-form {
            margin-top: 20px;
        }
        .search-form input[type="text"] {
            padding: 8px;
            width: 200px;
        }
        .search-form input[type="submit"] {
            padding: 8px 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            margin-left: 10px;
        }
        .search-form input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .logout {
            text-align: right;
            margin-top: 10px;
        }
        .logout a {
            text-decoration: none;
            color: #333;
            background-color: #dc3545;
            padding: 8px 12px;
            border-radius: 4px;
        }
        .logout a:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Admin Panel</h2>

    <div class="logout">
        <a href="admin_logout.php">Logout</a>
    </div>

    <div class="search-form">
        <form action="admin_panel.php" method="get">
            <input type="text" name="search" placeholder="Search by Name">
            <input type="submit" value="Search">
        </form>
    </div>

    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Action</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo $user['name']; ?></td>
            <td><?php echo $user['email']; ?></td>
            <td><?php echo $user['phone']; ?></td>
            <td><?php echo $user['address']; ?></td>
            <td>
                <div class="edit-form">
                    <form action="admin_panel.php" method="post">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <input type="text" name="name" value="<?php echo $user['name']; ?>">
                        <input type="text" name="email" value="<?php echo $user['email']; ?>">
                        <input type="text" name="phone" value="<?php echo $user['phone']; ?>">
                        <input type="text" name="address" value="<?php echo $user['address']; ?>">
                        <input type="submit" name="update_user" value="Update">
                    </form>
                    <form action="admin_panel.php" method="get">
                        <input type="hidden" name="delete" value="<?php echo $user['id']; ?>">
                        <input type="submit" value="Delete" onclick="return confirm('Are you sure you want to delete this user?');">
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

</body>
</html>
