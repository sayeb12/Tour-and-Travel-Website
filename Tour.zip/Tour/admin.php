<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $admin_name = $mysqli->real_escape_string($_POST['admin_name']);
    $admin_email = $mysqli->real_escape_string($_POST['admin_email']);
    $admin_password = $mysqli->real_escape_string($_POST['admin_password']);

    // Hash the password for security
    $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

    // Prepare the SQL statement
    $sql = "INSERT INTO admins (admin_name, admin_email, admin_password) VALUES ('$admin_name', '$admin_email', '$hashed_password')";

    // Execute the query
    if ($mysqli->query($sql) === TRUE) {
        echo "Admin registered successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $mysqli->error;
    }

    // Close the connection
    $mysqli->close();
}
?>
